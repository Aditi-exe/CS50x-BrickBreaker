**CS50x Final Project 2020 - BrickBreaker Game**

This project is a take on the 1976 Atari game Breakout. It is coded in Lua and run on LOVE2D.


**Description**

This game is a modern version of the classic Breakout. It makes use of the various functions provided by Lua
like the _math.randomseed_ function to randomise brick patterns.
The game has two levels of different themes (space and underwater) and diffculties. The difficulty of each level increases as the ball speed
gets faster with each collision with the paddle and bricks.
The goal is to get the highest score before running out of lives.


**How to use**

The code can be run directly with LOVE2D by dragging and dropping the game files.


**Requirements**

LOVE2D


**Credits**

Fonts taken from:
dafont.com
fontmeme.com
fontget.com

Brick and ball spritesheets taken from:
opengameart.com

Sounds downloaded from:
bfxr
storyblocks.com


