--[[
    The paddle that is going to be used is an image.
]]


Paddle = Class{}

require 'SMap'

-- size of paddle in pixels
PADDLE_WIDTH = 64
PADDLE_HEIGHT = 12

-- speed of paddle
PADDLE_SPEED = 200

-- initializes the paddle, takes in x and y coordinates and an image as arguments
function Paddle:init(x, y, width, height)
    self.x = x
    self.y = y
    self.width = PADDLE_WIDTH
    self.height = PADDLE_HEIGHT
    self.dx = 0

    self.map = map
    self.texture = love.graphics.newImage('graphics/paddle_styles/paddle_resized_2.png')

end

function Paddle:update(dt)
    
    self.x = self.x + self.dx * dt

    -- making sure that the paddle doesn't move beyond the screen
    -- by returning the minimum / maximum value between the size of 
    -- the screen and the x-coordinate of the paddle

    if self.dx < 0 then
        -- for the left edge of the screen
        self.x = math.max(0, self.x + self.dx * dt)
    end

    if self.dx > 0 then
        -- for the right edge if the screen
        self.x = math.min(VIRTUAL_WIDTH - PADDLE_WIDTH, self.x + self.dx * dt)
    end

    love.graphics.draw(self.texture, self.x, VIRTUAL_HEIGHT - self.height)

end

function Paddle:render()
    love.graphics.draw(self.texture, self.x, self.y)
end
