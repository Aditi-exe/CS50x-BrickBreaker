--[[
    CS50x's Final Project for 2020
    A version of BrickBreaker
    Author: Aditi Sathe (GitHub username: Aditi-exe)
    Original Credit: Atari 
]]

Class = require 'class'
push = require 'push'

require 'Ball'
require 'SMap'
require 'Paddle'
require 'UMap'

-- resolution close to Atari but 16:9
VIRTUAL_WIDTH = 1280
VIRTUAL_HEIGHT = 720

-- actual window resolution
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720

-- seeding random number generator (RNG)
math.randomseed(os.time())

-- map object to store the space map data
smap = SMap()

-- map object to store the underwater map data
umap = UMap()

-- ball objects to store ball data
play_ball = Ball(VIRTUAL_WIDTH / 2, VIRTUAL_HEIGHT / 2 + 10, BALL_WIDTH, BALL_HEIGHT, smap)
play_ball_2 = Ball(VIRTUAL_WIDTH / 2, VIRTUAL_HEIGHT / 2 + 10, BALL_WIDTH, BALL_HEIGHT, umap)


-- paddle object to store paddle data
player = Paddle(VIRTUAL_WIDTH / 2 - PADDLE_WIDTH, VIRTUAL_HEIGHT - 45, 
                PADDLE_WIDTH, PADDLE_HEIGHT)
player_2 = Paddle(VIRTUAL_WIDTH / 2 - PADDLE_WIDTH, VIRTUAL_HEIGHT - 88,
                PADDLE_WIDTH, PADDLE_HEIGHT)


-- makes upscaling look less blurry
love.graphics.setDefaultFilter('nearest', 'nearest')

-- counter to check for lives (chances) lost
lives = 3

-- remove brick counter
removed = 0

-- score counter
score = 0
score_2 = 0

-- reset counter
reset_count = 0
reset = false
lives = 3

-- to print the remaining lives
x_coord = 0
y_coord = 320

blankTileCount = 0
emptyTileCount = 0

INSTRUCTIONS = [[
                Hit the bricks with the ball by moving the paddle till all the bricks have been destroyed.

                You start with three lives. If the ball crosses the bottom boundary, you lose a life.

                Finish with the highest score possible!
                
                Controls:
                -> Move right: right arrow key
                -> Move left: left arrow key
                
                Press c to continue.
                ]]

LEVELS = [[
            1. Space Odyssey
            2. Underwater Utopia


               Space Odyssey Points:                        Underwater Utopia Points

            -> Red bricks: 10 pts                            -> Dark blue bricks: 10 pts 
            -> Blue bricks: 10 pts                           -> Light blue bricks: 10 pts 
            -> Grey bricks: 15 pts                           -> Sky blue bricks: 10 pts
            -> Purple bricks: 20 pts                      -> Aquamarine bricks: 15 pts
            -> Golden bricks: 50 pts                     -> Pink-gold bricks: 20 pts
                                                                           -> Dark green bricks: 50 pts


            Press 1 for Option 1. or 2 for Option 2.
            Press enter / return for instructions.

         ]]

-- variable to check which key was pressed
waspressed = 0

-- variable to check which letter key was pressed
keyWasPressed = ''


-- table to store all sounds
sounds = {
    ['ball_hit_brick_space'] = love.audio.newSource('sounds/Ball_hit_brick_2.wav', 'static'),
    ['ball_hit_paddle_space'] = love.audio.newSource('sounds/Ball_hit_paddle_2.wav', 'static'),
    ['ball_lost_space'] = love.audio.newSource('sounds/Ball_lost_2.wav', 'static'),
    ['ball_hit_brick_water'] = love.audio.newSource('sounds/Ball_hit_brick_water_2.wav', 'static'),
    ['ball_hit_paddle_water'] = love.audio.newSource('sounds/Ball_hit_paddle_water_2.wav', 'static'),
    ['ball_lost_water'] = love.audio.newSource('sounds/Ball_lost_water_2.wav', 'static'),
    ['ball_hit_wall_space'] = love.audio.newSource('sounds/ball_hit_wall_space_2.wav', 'static'),
    ['ball_hit_wall_water'] = love.audio.newSource('sounds/ball_hit_wall_water.wav', 'static'),
    ['intro'] = love.audio.newSource('sounds/intro_final_2.wav', 'static')
}

-- initializing all objects and data required by the program
function love.load()

    -- setting up a font for the title screen
    titleFont = love.graphics.newFont('fonts/paladins/paladins.ttf', 64)

    -- setting up a smaller subheading font for the instructions and menu screen
    subheadingFont = love.graphics.newFont('fonts/rapier_zero/Rapier Zero.otf', 32)

    -- setting up a smaller font for the actual instructions
    smallFont = love.graphics.newFont('fonts/rapier_zero/Rapier Zero.otf', 20)

    -- sea decor font
    seaDecor = love.graphics.newFont('fonts/underwater_logos/Lalinea Sea.ttf', 100)

    -- aqua fonts
    aqua = love.graphics.newFont('fonts/aquawax/Aquawax Black Trial.ttf', 44)
    aquaSmall = love.graphics.newFont('fonts/aquawax/Aquawax Medium Trial.ttf', 20)
    aquaThin = love.graphics.newFont('fonts/aquawax/Aquawax Light Trial.ttf', 20)

    -- space decor font
    space = love.graphics.newFont('fonts/sci_fi_logos/Space.ttf', 100)
    space2 = love.graphics.newFont('fonts/sci_fi_logos/SPACWE__.TTF', 64)

    pirulen = love.graphics.newFont('fonts/pirulen/pirulen rg.ttf', 44)
    pirulenSmall = love.graphics.newFont('fonts/pirulen/pirulen rg.ttf', 20)

    neuropolitical = love.graphics.newFont('fonts/neuropolitical/neuropolitical rg.ttf', 44)
    neuropoliticalSmall = love.graphics.newFont('fonts/neuropolitical/neuropolitical rg.ttf', 20)

    quicksand = love.graphics.newFont('fonts/quicksand/Quicksand_Bold.otf', 44)
    quicksandMedium = love.graphics.newFont('fonts/quicksand/Quicksand_Bold.otf', 30)
    quicksandSmall = love.graphics.newFont('fonts/quicksand/Quicksand_Bold.otf', 20)

    finalfrontier = love.graphics.newFont('fonts/other_fonts/Finalnew.ttf', 44)
    finalfrontierSmall = love.graphics.newFont('fonts/other_fonts/Finalnew.ttf', 24)

    bordermon = love.graphics.newFont('fonts/bordermon/BORDMS__.TTF', 40)

    airlock = love.graphics.newFont('fonts/other_fonts/airlock/airlock.regular.ttf', 16)

    bubbles = love.graphics.newFont('fonts/other_fonts/bubble.ttf', 36)




    -- setting up a virtual screen resolution
    push:setupScreen(VIRTUAL_WIDTH, VIRTUAL_HEIGHT, WINDOW_WIDTH, WINDOW_HEIGHT, {
        fullscreen = false,
        resizable = true,
        vsync = true,
        highdpi = true
    })

    -- set a title to the game window
    love.window.setTitle('BrickBreaker')

    gameState = 'title'

    title_background = love.graphics.newImage('graphics/backgrounds/title_background.png')

    -- increment variable to increase the speed of the ball gradually
    speed_increment = 0.01
    speed_increment_2 = 0.01


    for i = 0, lives do
        love.graphics.draw(play_ball_2.texture, x_coord, y_coord)
        x_coord = x_coord + 12
    end


end

-- called whener window is resized
function love.resize(w, h)
    push:resize(w, h)
end

-- called whenever a key is pressed; in this case - close the window when escape is pressed
function love.keypressed(key)
    if key == 'escape' then
        love.event.quit()
    end

    if key == 'enter' or key == 'return' then
        gameState = 'instructions'
    end

    if key == 'c' then
        gameState = 'menu'
    end

    if key == '1' then
        wasPressed = 1
        gameState = 'start'
    end

    if key == '2' then
        wasPressed = 2
        gameState = 'start'
    end

    if key == 'b' then
        keyWasPressed = 'b' 
        gameState = 'play'
    end
end

function love.update(dt)

    -- setting paddle speed according to whether the right or left key is pressed
    if love.keyboard.isDown('right') then
        player.dx = PADDLE_SPEED
        player_2.dx = PADDLE_SPEED
    elseif love.keyboard.isDown('left') then
        player.dx = -PADDLE_SPEED
        player_2.dx = -PADDLE_SPEED
    else
        player.dx = 0
        player_2.dx = 0
    end

    BALL_X = math.floor(play_ball.x / 64)
    BALL_Y = math.floor(play_ball.y / 32)
    
    BALL_X_2 = math.floor(play_ball_2.x / 64)
    BALL_Y_2 = math.floor(play_ball_2.y / 32)

    -- playing the first map
    if wasPressed == 1 and keyWasPressed == 'b' and gameState == 'play' then
        play_ball:update(dt)

        if play_ball:collidesPaddle(player) then
            play_ball.dx = play_ball.dx + math.random(-10, 10)
            play_ball.dy = BALL_SPEED_UP + BALL_SPEED_UP * speed_increment
            sounds['ball_hit_paddle_space']:play()
            speed_increment = speed_increment + 0.01
        end

        -- check left wall collision
        if play_ball.x <= 0 then
            play_ball.x = 0
            play_ball.dx = -play_ball.dx
            sounds['ball_hit_wall_space']:play()
        end

        -- check right wall collision, 12 to account for the ball's width
        if play_ball.x >= VIRTUAL_WIDTH - 12 then
            play_ball.x = VIRTUAL_WIDTH - 12
            play_ball.dx = -play_ball.dx
            sounds['ball_hit_wall_space']:play()
        end

        -- check top wall collision
        if play_ball.y <= 0 then
            play_ball.y = 0
            play_ball.dy = -play_ball.dy
            sounds['ball_hit_wall_space']:play()
        end

        -- check bottom collision
        if play_ball.y >= VIRTUAL_HEIGHT then
            play_ball:reset()
            reset_count = reset_count + 1
            sounds['ball_lost_space']:play()
            speed_increment = 0.01
            lives = lives - 1
        end

        -- WORKS GREAT
        if play_ball:brickHit(play_ball.x, play_ball.y) == true or play_ball:brickHit(play_ball.x + 12, play_ball.y + 12) == true then
            sounds['ball_hit_brick_space']:play()
            play_ball.dy = BALL_SPEED_DOWN + BALL_SPEED_DOWN * speed_increment
            speed_increment = speed_increment + 0.01

            if smap:tileAt(play_ball.x, play_ball.y).id == RED then
                -- check if the brick hit is a red brick:

                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), RED_2)

            elseif smap:tileAt(play_ball.x, play_ball.y).id == RED_2 then

                score = score + 10
                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), BLANK_TILE)
                blankTileCount = blankTileCount + 1

            elseif smap:tileAt(play_ball.x, play_ball.y).id == BLUE then
                -- check if the brick hit is a blue brick

                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), BLUE_2)

            elseif smap:tileAt(play_ball.x, play_ball.y).id == BLUE_2 then

                score = score + 10
                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), BLANK_TILE)
                blankTileCount = blankTileCount + 1

            elseif smap:tileAt(play_ball.x, play_ball.y).id == GREY then
                -- check if the brick hit is a grey brick

                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), GREY_2)

            elseif smap:tileAt(play_ball.x, play_ball.y).id == GREY_2 then

                score = score + 15
                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), BLANK_TILE)
                blankTileCount = blankTileCount + 1

            elseif smap:tileAt(play_ball.x, play_ball.y).id == PURPLE then
                -- check if the brick hit is a purple brick

                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), PURPLE_2)

            elseif smap:tileAt(play_ball.x, play_ball.y).id == PURPLE_2 then

                score = score + 20
                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), BLANK_TILE)
                blankTileCount = blankTileCount + 1

            elseif smap:tileAt(play_ball.x, play_ball.y).id == GOLDEN then
                -- check if the brick hit is a golden tile

                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), GOLDEN_2)

            elseif smap:tileAt(play_ball.x, play_ball.y).id == GOLDEN_2 then

                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), GOLDEN_3)

            elseif smap:tileAt(play_ball.x, play_ball.y).id == GOLDEN_3 then

                score = score + 50
                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), BLANK_TILE)
                blankTileCount = blankTileCount + 1

            else
                smap:setTile(BALL_X + 1, math.max(BALL_Y, BALL_Y - 1), BLANK_TILE)
                blankTileCount = blankTileCount + 1
            end
        end

        if reset_count == 3 then
            gameState = 'done'
        end

    end

    -- playing the second map
    if wasPressed == 2 and keyWasPressed == 'b' and gameState == 'play' then
        play_ball_2:update(dt)

        if play_ball_2:collidesPaddle(player_2) then
            play_ball_2.dx = play_ball_2.dx + math.random(-10, 10)
            play_ball_2.dy = BALL_SPEED_UP + BALL_SPEED_UP * speed_increment_2
            sounds['ball_hit_paddle_water']:play()
            speed_increment_2 = speed_increment_2 + 0.03
        end

        -- check left wall collision
        if play_ball_2.x <= 0 then
            play_ball_2.x = 0
            play_ball_2.dx = -play_ball_2.dx
            sounds['ball_hit_wall_water']:play()
        end

        -- check right wall collision, 12 to account for the ball's width
        if play_ball_2.x >= VIRTUAL_WIDTH - 12 then
            play_ball_2.x = VIRTUAL_WIDTH - 12
            play_ball_2.dx = -play_ball_2.dx
            sounds['ball_hit_wall_water']:play()
        end

        -- check top wall collision
        if play_ball_2.y <= 0 then
            play_ball_2.y = 0
            play_ball_2.dy = -play_ball_2.dy
            sounds['ball_hit_wall_water']:play()
        end

        -- check bottom collision
        if play_ball_2.y >= VIRTUAL_HEIGHT then
            play_ball_2:reset()
            reset_count = reset_count + 1
            sounds['ball_lost_water']:play()
            speed_increment_2 = 0.01
            lives = lives - 1
        end

        -- WORKS GREAT
        if play_ball_2:brickHit(play_ball_2.x, play_ball_2.y) == true or play_ball_2:brickHit(play_ball_2.x + 12, play_ball_2.y + 12) == true then
            play_ball_2.dy = BALL_SPEED_DOWN + BALL_SPEED_DOWN * speed_increment_2
            sounds['ball_hit_brick_water']:play()
            speed_increment_2 = speed_increment_2 + 0.03

            if umap:tileAt(play_ball_2.x, play_ball_2.y).id == DARK_BLUE then
                -- check if the brick hit is a dark blue brick:

                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), DARK_BLUE_2)

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == DARK_BLUE_2 then

                score_2 = score_2 + 10
                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), BLANK_TILE)
                emptyTileCount = emptyTileCount + 1

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == LIGHT_BLUE then
                -- check if the brick hit is a light blue brick

                score_2 = score_2 + 10
                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), BLANK_TILE)
                emptyTileCount = emptyTileCount + 1

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == SKY_BLUE then
                -- check if the brick hit is a sky blue brick
                score_2 = score_2 + 10
                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), BLANK_TILE)
                emptyTileCount = emptyTileCount + 1

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == AQUAMARINE then
                -- check if the brick hit is a aquamarine brick

                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), AQUAMARINE_2)

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == AQUAMARINE_2 then

                score_2 = score_2 + 15
                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), BLANK_TILE)
                emptyTileCount = emptyTileCount + 1

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == PINK_GOLD then
                -- check if the brick hit is a pink gold brick

                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), PINK_GOLD_2)

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == PINK_GOLD_2 then

                score_2 = score_2 + 20
                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), BLANK_TILE)
                emptyTileCount = emptyTileCount + 1

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == DARK_GREEN then
                -- check if the brick hit is a dark green tile

                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), DARK_GREEN_2)

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == DARK_GREEN_2 then

                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), DARK_GREEN_3)

            elseif umap:tileAt(play_ball_2.x, play_ball_2.y).id == DARK_GREEN_3 then

                score_2 = score_2 + 50
                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), BLANK_TILE)
                emptyTileCount = emptyTileCount + 1

            else
                umap:setTile(BALL_X_2 + 1, math.max(BALL_Y_2, BALL_Y_2 - 1), BLANK_TILE)
                emptyTileCount = emptyTileCount + 1
            end
        end

        if reset_count == 3 then
            gameState = 'done'
        end

    end

    -- ending the game (winning)
    if smap:mapClear() == true then
        gameState = 'win'
    end

    if umap:mapClear2() == true then
        gameState = 'win'
    end

    player:update(dt)
    player_2:update(dt)
end

-- rendering the screen
function love.draw()

    -- begin virtual resolution drawing
    push:apply('start')

    -- clear screen using navy blue 
    --love.graphics.clear(7 / 255, 55 / 255, 99 / 255)

    --clear the screen using black
    --love.graphics.clear(0, 0, 0, 0)
    
    -- title screen
    if gameState == 'title' then
        love.graphics.clear(0, 0, 0, 0)
        love.graphics.draw(title_background)
        love.graphics.setFont(titleFont)
        love.graphics.print('BrickBreaker', VIRTUAL_WIDTH / 2 - 362.5, VIRTUAL_HEIGHT / 2 - 50)
        love.graphics.setFont(smallFont)
        love.graphics.print('Press ENTER to continue', VIRTUAL_WIDTH / 2 - 160, VIRTUAL_HEIGHT / 2 + 50)
        sounds['intro']:play()
    end

    -- instructions screen
    if gameState == 'instructions' then
        love.graphics.clear(7 / 255, 55 / 255, 99 / 255)
        love.graphics.setFont(finalfrontier)
        love.graphics.print('INSTRUCTIONS: ', 10, 64)
        love.graphics.setFont(finalfrontierSmall)
        love.graphics.print(INSTRUCTIONS, 10, 128)
        sounds['intro']:play()
    end

    -- menu screen - choose level
    if gameState == 'menu' then
        love.graphics.clear(7 / 255, 55 / 255, 99 / 255)
        love.graphics.setFont(finalfrontier)
        love.graphics.print('CHOOSE A LEVEL: ', 10, 64)
        love.graphics.setFont(finalfrontierSmall)
        love.graphics.print(LEVELS, 10, 128)
        sounds['intro']:play()
    end






    -- rendering everything for map 1
    if wasPressed == 1 and gameState == 'start' then
        sounds['intro']:stop()
        love.graphics.clear(0, 0, 0, 0)
        if reset_count == 0 then
            smap:render()
            play_ball:render()
            player:render()
            love.graphics.setFont(smallFont)
            love.graphics.print('Press b to begin!', VIRTUAL_WIDTH / 2 - 100, VIRTUAL_HEIGHT / 2 + 20)

            love.graphics.print('SCORE : '..score, 0, 320)
            love.graphics.print('LIVES : '..lives, 0, 340)

            love.graphics.setFont(airlock)
            love.graphics.setColor(255, 255, 0)
            love.graphics.print('/////////////////////////////////////////////////////////////////////////////////////////////////////////////', 0, VIRTUAL_HEIGHT - 20)


            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.circle("fill", 50, 380, 1)
            love.graphics.circle("fill", 1100, 390, 5)
            love.graphics.circle("fill", 300, 400, 2)
            love.graphics.circle("fill", 450, 350, 3)
            love.graphics.circle("fill", 500, 450, 4)
            love.graphics.circle("fill", 1000, 330, 4)
            love.graphics.circle("fill", 225, 475, 3)
            love.graphics.circle("fill", 590, 600, 2)
            love.graphics.circle("fill", 180, 690, 4)
            love.graphics.circle("fill", 850, 650, 2)
            love.graphics.circle("fill", 20, 400, 2)
            love.graphics.circle("fill", 1150, 690, 3)
            love.graphics.circle("fill", 75, 560, 4)
            love.graphics.circle("fill", 15, 580, 1)
            love.graphics.circle("fill", 1175, 550, 3)
            love.graphics.circle("fill", 500, 400, 1)
            love.graphics.circle("fill", 565, 560, 3)
            love.graphics.circle("fill", 350, 550, 3)
            love.graphics.circle("fill", 900, 480, 4)
            love.graphics.circle("fill", 950, 550, 4)

        else
            sounds['intro']:stop()
            smap:render()
            play_ball:render()
            player:render()
            love.graphics.setFont(smallFont)
            love.graphics.print('You lost a life! Press b to start again.', VIRTUAL_WIDTH / 2 - 220, VIRTUAL_HEIGHT / 2 + 20)

            love.graphics.setFont(smallFont)
            love.graphics.print('SCORE : '..score, 0, 320)
            love.graphics.print('LIVES : '..lives, 0, 340)

            love.graphics.setFont(airlock)
            love.graphics.setColor(255, 255, 0)
            love.graphics.print('/////////////////////////////////////////////////////////////////////////////////////////////////////////////', 0, VIRTUAL_HEIGHT - 20)


            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.circle("fill", 50, 380, 1)
            love.graphics.circle("fill", 1100, 390, 5)
            love.graphics.circle("fill", 300, 400, 2)
            love.graphics.circle("fill", 450, 350, 3)
            love.graphics.circle("fill", 500, 450, 4)
            love.graphics.circle("fill", 1000, 330, 4)
            love.graphics.circle("fill", 225, 475, 3)
            love.graphics.circle("fill", 590, 600, 2)
            love.graphics.circle("fill", 180, 690, 4)
            love.graphics.circle("fill", 850, 650, 2)
            love.graphics.circle("fill", 20, 400, 2)
            love.graphics.circle("fill", 1150, 690, 3)
            love.graphics.circle("fill", 75, 560, 4)
            love.graphics.circle("fill", 15, 580, 1)
            love.graphics.circle("fill", 1175, 550, 3)
            love.graphics.circle("fill", 500, 400, 1)
            love.graphics.circle("fill", 565, 560, 3)
            love.graphics.circle("fill", 350, 550, 3)
            love.graphics.circle("fill", 900, 480, 4)
            love.graphics.circle("fill", 950, 550, 4)

        end

    end

    -- rendering the map corresponding to option 1 while playing
    if wasPressed == 1 and keyWasPressed == 'b' and gameState == 'play' then
        smap:render()
        play_ball:render()
        player:render()

        love.graphics.setFont(smallFont)
        love.graphics.print('SCORE : '..score, 0, 320)
        love.graphics.print('LIVES : '..lives, 0, 340)


        love.graphics.setFont(airlock)
        love.graphics.setColor(255, 255, 0)
        love.graphics.print('/////////////////////////////////////////////////////////////////////////////////////////////////////////////', 0, VIRTUAL_HEIGHT - 20)


        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.circle("fill", 50, 380, 1)
        love.graphics.circle("fill", 1100, 390, 5)
        love.graphics.circle("fill", 300, 400, 2)
        love.graphics.circle("fill", 450, 350, 3)
        love.graphics.circle("fill", 500, 450, 4)
        love.graphics.circle("fill", 1000, 330, 4)
        love.graphics.circle("fill", 225, 475, 3)
        love.graphics.circle("fill", 590, 600, 2)
        love.graphics.circle("fill", 180, 690, 4)
        love.graphics.circle("fill", 850, 650, 2)
        love.graphics.circle("fill", 20, 400, 2)
        love.graphics.circle("fill", 1150, 690, 3)
        love.graphics.circle("fill", 75, 560, 4)
        love.graphics.circle("fill", 15, 580, 1)
        love.graphics.circle("fill", 1175, 550, 3)
        love.graphics.circle("fill", 500, 400, 1)
        love.graphics.circle("fill", 565, 560, 3)
        love.graphics.circle("fill", 350, 550, 3)
        love.graphics.circle("fill", 900, 480, 4)
        love.graphics.circle("fill", 950, 550, 4)

    end

    -- resetting the ball for map 1
    if wasPressed == 1 and keyWasPressed == 'b' and gameState == 'reset' then
        smap:render()
        play_ball:render()
        player:render()
        love.graphics.setFont(smallFont)
        love.graphics.print('You lost a life! Press b to start again.', VIRTUAL_WIDTH / 2 - 220, VIRTUAL_HEIGHT / 2 + 20)
        love.graphics.print('SCORE : '..score, 0, 320)
        love.graphics.print('LIVES : '..lives, 0, 340)


        love.graphics.setFont(airlock)
        love.graphics.setColor(255, 255, 0)
        love.graphics.print('/////////////////////////////////////////////////////////////////////////////////////////////////////////////', 0, VIRTUAL_HEIGHT - 20)


        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.circle("fill", 50, 380, 1)
        love.graphics.circle("fill", 1100, 390, 5)
        love.graphics.circle("fill", 300, 400, 2)
        love.graphics.circle("fill", 450, 350, 3)
        love.graphics.circle("fill", 500, 450, 4)
        love.graphics.circle("fill", 1000, 330, 4)
        love.graphics.circle("fill", 225, 475, 3)
        love.graphics.circle("fill", 590, 600, 2)
        love.graphics.circle("fill", 180, 690, 4)
        love.graphics.circle("fill", 850, 650, 2)
        love.graphics.circle("fill", 20, 400, 2)
        love.graphics.circle("fill", 1150, 690, 3)
        love.graphics.circle("fill", 75, 560, 4)
        love.graphics.circle("fill", 15, 580, 1)
        love.graphics.circle("fill", 1175, 550, 3)
        love.graphics.circle("fill", 500, 400, 1)
        love.graphics.circle("fill", 565, 560, 3)
        love.graphics.circle("fill", 350, 550, 3)
        love.graphics.circle("fill", 900, 480, 4)
        love.graphics.circle("fill", 950, 550, 4)

    end

    -- ending the game for map 1
    if wasPressed == 1 and gameState == 'done' then
        love.graphics.setFont(subheadingFont, 'center')
        love.graphics.print('You lose!', VIRTUAL_WIDTH / 2 - 80, VIRTUAL_HEIGHT / 2)
        love.graphics.setFont(smallFont)
        love.graphics.print('Final Score: '..score, VIRTUAL_WIDTH / 2 - 74, VIRTUAL_HEIGHT / 2 + 64)

        love.graphics.setFont(airlock)
        love.graphics.setColor(255, 255, 0)
        love.graphics.print('//////////////////////////////////////////////////////////////////////////////////////////////////////////', 0, VIRTUAL_HEIGHT - 20)
        love.graphics.print('//////////////////////////////////////////////////////////////////////////////////////////////////////////', 0, 20)

    end








    -- rendering everything for map 2
    if wasPressed == 2 and gameState == 'start' then
        sounds['intro']:stop()
        love.graphics.clear(5 / 255, 55 / 255, 99 / 255)
        umap:render()
        play_ball_2:render()
        player_2:render()

        love.graphics.setFont(aquaThin)
        love.graphics.print('Press b to begin!', VIRTUAL_WIDTH / 2 - 70, VIRTUAL_HEIGHT / 2 + 20)
        love.graphics.setFont(seaDecor)
        love.graphics.setColor(0, 255, 0, 255)
        love.graphics.print('abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefg', 0, VIRTUAL_HEIGHT - 88)
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.setFont(quicksandSmall)
        love.graphics.print('SCORE : '..score_2, 0, 320)
        love.graphics.print('LIVES : '..lives, 0, 340)

    end

    -- rendering the map corresponding to option 2 while playing
    if wasPressed == 2 and keyWasPressed == 'b' and gameState == 'play' then
        love.graphics.clear(5 / 255, 55 / 255, 99 / 255)
        umap:render()
        play_ball_2:render()
        player_2:render()
        love.graphics.setFont(seaDecor)
        love.graphics.setColor(0, 255, 0, 255)
        love.graphics.print('abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefg', 0, VIRTUAL_HEIGHT - 88)
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.setFont(quicksandSmall)
        love.graphics.print('SCORE : '..score_2, 0, 320)
        love.graphics.print('LIVES : '..lives, 0, 340)

    end

    -- resetting the ball for map 2
    if wasPressed == 2 and keyWasPressed == 'b' and gameState == 'reset' then
        love.graphics.clear(5 / 255, 55 / 255, 99 / 255)
        umap:render()
        play_ball_2:render()
        player_2:render()
        love.graphics.setFont(aquaThin)
        love.graphics.print('You lost a life! Press b to start again.', VIRTUAL_WIDTH / 2 - 160, VIRTUAL_HEIGHT / 2 + 20)
        love.graphics.setFont(seaDecor)
        love.graphics.setColor(0, 255, 0, 255)
        love.graphics.print('abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefg', 0, VIRTUAL_HEIGHT - 88)
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.setFont(quicksandSmall)
        love.graphics.print('SCORE : '..score_2, 0, 320)
        love.graphics.print('LIVES : '..lives, 0, 340)

    end

    -- ending the game for map 2
    if wasPressed == 2 and gameState == 'done' then
        love.graphics.setFont(quicksand, 'center')
        love.graphics.print('You lose!', VIRTUAL_WIDTH / 2 - 85, VIRTUAL_HEIGHT / 2 - 30)
        love.graphics.setFont(quicksandMedium, 'center')
        love.graphics.print('Final Score : '..score_2, VIRTUAL_WIDTH / 2 - 90, VIRTUAL_HEIGHT / 2 + 34)
        love.graphics.setFont(seaDecor)
        love.graphics.setColor(0, 255, 0, 255)
        love.graphics.print('qwasbgfchjhnytpasdfghjklzxcvbnmlkjhgfdsapoiuytrewqmnbvcxz', 0, VIRTUAL_HEIGHT - 88)
    end


    -- winning map 1
    if wasPressed == 1 and gameState == 'win' then
        love.graphics.clear(0, 0, 0, 0)
        love.graphics.setFont(subheadingFont)
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.print('You win!', VIRTUAL_WIDTH / 2 - 70, VIRTUAL_HEIGHT / 2)
        love.graphics.setFont(smallFont)
        love.graphics.print('Score: '..score, VIRTUAL_WIDTH / 2 - 50, VIRTUAL_HEIGHT / 2 + 40)
        love.graphics.setFont(bordermon)
        love.graphics.setColor(255, 255, 0)
        love.graphics.print('BCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBC', 0, VIRTUAL_HEIGHT - 32)
        love.graphics.print('BCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBCBC', 0, 32)
        love.graphics.setFont(space2)
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.print('E', 1000, 200)
        --love.graphics.print('B', 100, 500)
    end

    -- winning map 2
    if wasPressed == 2 and gameState == 'win' then
        love.graphics.clear(5 / 255, 55 / 255, 99 / 255)
        love.graphics.setFont(quicksand)
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.print('You win!', VIRTUAL_WIDTH / 2 - 80, VIRTUAL_HEIGHT / 2)
        love.graphics.setFont(quicksandSmall)
        love.graphics.print('Score: '..score_2, VIRTUAL_WIDTH / 2 - 32, VIRTUAL_HEIGHT / 2 + 64)

        love.graphics.setFont(bubbles)
        love.graphics.setColor(255 / 255, 255 / 255, 255 / 255)
        love.graphics.print('e', 900, 400)
        love.graphics.print('r', 200, 300)
        love.graphics.print('e', 150, 200)
        love.graphics.print('r', 50, 500)
        love.graphics.print('e', 1100, 650)
        love.graphics.print('r', 400, 630)
        love.graphics.print('e', 1150, 60)

    end


    -- end virtual resolution
    push:apply('end')

end