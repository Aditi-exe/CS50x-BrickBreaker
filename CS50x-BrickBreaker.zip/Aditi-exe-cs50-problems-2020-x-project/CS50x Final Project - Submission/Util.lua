--[[
    This class stores utility functions that may need to be used in various parts of the program,
    even repeatedly sometimes.
]]

--[[ 
    Chopping up the spritesheet into 80 blocks caled 'quads' as the size of the spritesheet is 10x8.
    These quads can be individually drawn.
]]

-- takes a texture, width and height of bricks and splits it into quads
function generateQuads(atlas, tilewidth, tileheight)
    -- sheetWidth and sheetHeight are in terms of number of blocks in the spritesheet
    -- since getWidth, tilewidth, getHeight and tileheight are in terms of number of pixels
    local sheetWidth = atlas:getWidth() / tilewidth
    local sheetHeight = atlas:getHeight() / tileheight

    -- default in Lua begins from 1
    local sheetCounter = 1

    -- table to store quads
    local quads = {}

    -- making square cutouts of the spritesheet instead of using the whole as one
    for y = 0, sheetHeight - 1 do
        for x = 0, sheetWidth - 1 do
            -- cutouts from the whole sheet are made here
            -- iterating over the whole sheet one block at a time
            quads[sheetCounter] = 
                love.graphics.newQuad(x * tilewidth, y * tileheight, tilewidth,
                tileheight, atlas:getDimensions())
            sheetCounter = sheetCounter + 1
        end
    end

    return quads
end


