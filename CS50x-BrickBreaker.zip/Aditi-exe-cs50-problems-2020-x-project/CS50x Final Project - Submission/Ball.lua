Ball = Class{}

require 'Paddle'
require 'SMap'
require 'UMap'

BALL_WIDTH = 12
BALL_HEIGHT = 12

BALL_SPEED_DOWN = 250
BALL_SPEED_UP = -250

--[[ class object to store functionality of that class
smap1 = SMap{}
]]

-- variables to keep track of number of collisions with each brick
countRed = 1
countBlue = 1
countGrey = 1
countPurple = 1
countGolden = 1

tileRemoved = 0

-- 2D table of coordinates of all brick positions (top left corners)
coordinates = {
    --[-1] = {{8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}, {8976, 4738}},
    [0] = {[0] = {x1 = 0, y1 = 0}, [1] = {x1 = 64, y1 = 0}, [2] = {x1 = 128, y1 = 0}, [3] = {x1 = 192, y1 = 0}, [4] = {x1 = 256, y1 = 0}, [5] = {x1 = 320, y1 = 0}, [6] = {x1 = 384, y1 = 0}, [7] = {x1 = 448, y1 = 0}, [8] = {x1 = 512, y1 = 0}, [9] = {x1 = 576, y1 = 0}, [10] = {x1 = 640, y1 = 0}, [11] = {x1 = 704, y1 = 0}, [12] = {x1 = 768, y1 = 0}, [13] = {x1 = 832, y1 = 0}, [14] = {x1 = 896, y1 = 0}, [15] = {x1 = 960, y1 = 0}, [16] = {x1 = 1024, y1 = 0}, [17] = {x1 = 1088, y1 = 0}, [18] = {x1 = 1152, y1 = 0}, [19] = {x1 = 1216, y1 = 0}, [20] = {x1 = 1280, y1 = 0}}, 
    [1] = {[0] = {x1 = 0, y1 = 32}, [1] = {x1 = 64, y1 = 32}, [2] = {x1 = 128, y1 = 32}, [3] = {x1 = 192, y1 = 32}, [4] = {x1 = 256, y1 = 32}, [5] = {x1 = 320, y1 = 32}, [6] = {x1 = 384, y1 = 32}, [7] = {x1 = 448, y1 = 32}, [8] = {x1 = 512, y1 = 32}, [9] = {x1 = 576, y1 = 32}, [10] = {x1 = 640, y1 = 32}, [11] = {x1 = 704, y1 = 32}, [12] = {x1 = 768, y1 = 32}, [13] = {x1 = 832, y1 = 32}, [14] = {x1 = 896, y1 = 32}, [15] = {x1 = 960, y1 = 32}, [16] = {x1 = 1024, y1 = 32}, [17] = {x1 = 1088, y1 = 32}, [18] = {x1 = 1152, y1 = 32}, [19] = {x1 = 1216, y1 = 32}, [20] = {x1 = 1280, y1 = 32}}, 
    [2] = {[0] = {x1 = 0, y1 = 64}, [1] = {x1 = 64, y1 = 64}, [2] = {x1 = 128, y1 = 64}, [3] = {x1 = 192, y1 = 64}, [4] = {x1 = 256, y1 = 64}, [5] = {x1 = 320, y1 = 64}, [6] = {x1 = 384, y1 = 64}, [7] = {x1 = 448, y1 = 64}, [8] = {x1 = 512, y1 = 64}, [9] = {x1 = 576, y1 = 64}, [10] = {x1 = 640, y1 = 64}, [11] = {x1 = 704, y1 = 64}, [12] = {x1 = 768, y1 = 64}, [13] = {x1 = 832, y1 = 64}, [14] = {x1 = 896, y1 = 64}, [15] = {x1 = 960, y1 = 64}, [16] = {x1 = 1024, y1 = 64}, [17] = {x1 = 1088, y1 = 64}, [18] = {x1 = 1152, y1 = 64}, [19] = {x1 = 1216, y1 = 64}, [20] = {x1 = 1280, y1 = 64}}, 
    [3] = {[0] = {x1 = 0, y1 = 96}, [1] = {x1 = 64, y1 = 96}, [2] = {x1 = 128, y1 = 96}, [3] = {x1 = 192, y1 = 96}, [4] = {x1 = 256, y1 = 96}, [5] = {x1 = 320, y1 = 96}, [6] = {x1 = 384, y1 = 96}, [7] = {x1 = 448, y1 = 96}, [8] = {x1 = 512, y1 = 96}, [9] = {x1 = 576, y1 = 96}, [10] = {x1 = 640, y1 = 96}, [11] = {x1 = 704, y1 = 96}, [12] = {x1 = 768, y1 = 96}, [13] = {x1 = 832, y1 = 96}, [14] = {x1 = 896, y1 = 96}, [15] = {x1 = 960, y1 = 96}, [16] = {x1 = 1024, y1 = 96}, [17] = {x1 = 1088, y1 = 96}, [18] = {x1 = 1152, y1 = 96}, [19] = {x1 = 1216, y1 = 96}, [20] = {x1 = 1280, y1 = 96}}, 
    [4] = {[0] = {x1 = 0, y1 = 128}, [1] = {x1 = 64, y1 = 128}, [2] = {x1 = 128, y1 = 128}, [3] = {x1 = 192, y1 = 128}, [4] = {x1 = 256, y1 = 128}, [5] = {x1 = 320, y1 = 128}, [6] = {x1 = 384, y1 = 128}, [7] = {x1 = 448, y1 = 128}, [8] = {x1 = 512, y1 = 128}, [9] = {x1 = 576, y1 = 128}, [10] = {x1 = 640, y1 = 128}, [11] = {x1 = 704, y1 = 128}, [12] = {x1 = 768, y1 = 128}, [13] = {x1 = 832, y1 = 128}, [14] = {x1 = 896, y1 = 128}, [15] = {x1 = 960, y1 = 128}, [16] = {x1 = 1024, y1 = 128}, [17] = {x1 = 1088, y1 = 128}, [18] = {x1 = 1152, y1 = 128}, [19] = {x1 = 1216, y1 = 128}, [20] = {x1 = 1280, y1 = 128}}, 
    [5] = {[0] = {x1 = 0, y1 = 160}, [1] = {x1 = 64, y1 = 160}, [2] = {x1 = 128, y1 = 160}, [3] = {x1 = 192, y1 = 160}, [4] = {x1 = 256, y1 = 160}, [5] = {x1 = 320, y1 = 160}, [6] = {x1 = 384, y1 = 160}, [7] = {x1 = 448, y1 = 160}, [8] = {x1 = 512, y1 = 160}, [9] = {x1 = 576, y1 = 160}, [10] = {x1 = 640, y1 = 160}, [11] = {x1 = 704, y1 = 160}, [12] = {x1 = 768, y1 = 160}, [13] = {x1 = 832, y1 = 160}, [14] = {x1 = 896, y1 = 160}, [15] = {x1 = 960, y1 = 160}, [16] = {x1 = 1024, y1 = 160}, [17] = {x1 = 1088, y1 = 160}, [18] = {x1 = 1152, y1 = 160}, [19] = {x1 = 1216, y1 = 160}, [20] = {x1 = 1280, y1 = 160}},
    [6] = {[0] = {x1 = 0, y1 = 192}, [1] = {x1 = 64, y1 = 192}, [2] = {x1 = 128, y1 = 192}, [3] = {x1 = 192, y1 = 192}, [4] = {x1 = 256, y1 = 192}, [5] = {x1 = 320, y1 = 192}, [6] = {x1 = 384, y1 = 192}, [7] = {x1 = 448, y1 = 192}, [8] = {x1 = 512, y1 = 192}, [9] = {x1 = 576, y1 = 192}, [10] = {x1 = 640, y1 = 192}, [11] = {x1 = 704, y1 = 192}, [12] = {x1 = 768, y1 = 192}, [13] = {x1 = 832, y1 = 192}, [14] = {x1 = 896, y1 = 192}, [15] = {x1 = 960, y1 = 192}, [16] = {x1 = 1024, y1 = 192}, [17] = {x1 = 1088, y1 = 192}, [18] = {x1 = 1152, y1 = 192}, [19] = {x1 = 1216, y1 = 192}, [20] = {x1 = 1280, y1 = 192}}, 
    [7] = {[0] = {x1 = 0, y1 = 224}, [1] = {x1 = 64, y1 = 224}, [2] = {x1 = 128, y1 = 224}, [3] = {x1 = 192, y1 = 224}, [4] = {x1 = 256, y1 = 224}, [5] = {x1 = 320, y1 = 224}, [6] = {x1 = 384, y1 = 224}, [7] = {x1 = 448, y1 = 224}, [8] = {x1 = 512, y1 = 224}, [9] = {x1 = 576, y1 = 224}, [10] = {x1 = 640, y1 = 224}, [11] = {x1 = 704, y1 = 224}, [12] = {x1 = 768, y1 = 224}, [13] = {x1 = 832, y1 = 224}, [14] = {x1 = 896, y1 = 224}, [15] = {x1 = 960, y1 = 224}, [16] = {x1 = 1024, y1 = 224}, [17] = {x1 = 1088, y1 = 224}, [18] = {x1 = 1152, y1 = 224}, [19] = {x1 = 1216, y1 = 224}, [20] = {x1 = 1280, y1 = 224}}, 
    [8] = {[0] = {x1 = 0, y1 = 256}, [1] = {x1 = 64, y1 = 256}, [2] = {x1 = 128, y1 = 256}, [3] = {x1 = 192, y1 = 256}, [4] = {x1 = 256, y1 = 256}, [5] = {x1 = 320, y1 = 256}, [6] = {x1 = 384, y1 = 256}, [7] = {x1 = 448, y1 = 256}, [8] = {x1 = 512, y1 = 256}, [9] = {x1 = 576, y1 = 256}, [10] = {x1 = 640, y1 = 256}, [11] = {x1 = 704, y1 = 256}, [12] = {x1 = 768, y1 = 256}, [13] = {x1 = 832, y1 = 256}, [14] = {x1 = 896, y1 = 256}, [15] = {x1 = 960, y1 = 256}, [16] = {x1 = 1024, y1 = 256}, [17] = {x1 = 1088, y1 = 256}, [18] = {x1 = 1152, y1 = 256}, [19] = {x1 = 1216, y1 = 256}, [20] = {x1 = 1280, y1 = 256}}, 
    [9] = {[0] = {x1 = 0, y1 = 288}, [1] = {x1 = 64, y1 = 288}, [2] = {x1 = 128, y1 = 288}, [3] = {x1 = 192, y1 = 288}, [4] = {x1 = 256, y1 = 288}, [5] = {x1 = 320, y1 = 288}, [6] = {x1 = 384, y1 = 288}, [7] = {x1 = 448, y1 = 288}, [8] = {x1 = 512, y1 = 288}, [9] = {x1 = 576, y1 = 288}, [10] = {x1 = 640, y1 = 288}, [11] = {x1 = 704, y1 = 288}, [12] = {x1 = 768, y1 = 288}, [13] = {x1 = 832, y1 = 288}, [14] = {x1 = 896, y1 = 288}, [15] = {x1 = 960, y1 = 288}, [16] = {x1 = 1024, y1 = 288}, [17] = {x1 = 1088, y1 = 288}, [18] = {x1 = 1152, y1 = 288}, [19] = {x1 = 1216, y1 = 288}, [20] = {x1 = 1280, y1 = 288}}
}

brickState = {
    [0] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [1] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [2] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [3] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [4] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [5] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [6] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [7] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [8] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 
    [9] = {[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0, [6] = 0, [7] = 0, [8] = 0, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 0, [16] = 0, [17] = 0, [18] = 0, [19] = 0,}, 

}

-- location of the ball in the x direction - as there are 20 bricks, there are 20 individual points where the ball can be
relative_ball_location_x = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}

-- location of the ball in the y direction - as there are 10 bricks, there are 10 individual points where the ball can be
relative_ball_location_y = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}


function Ball:init(x, y, width, height, map)
    self.x = x 
    self.y = y 
    self.width = width
    self.height = height

    self.map = map

    self.texture = love.graphics.newImage('graphics/ball_styles/ball_resized_2.png')

    -- initialising some starting speed to the ball
    self.dx = math.random(2) == 1 and math.random(-80, -100) or math.random(80, 100)
    self.dy = BALL_SPEED_DOWN

    -- player
    self.player1 = Paddle(self)

    -- to check if a brick has been removed
    removed = 0
end

-- expects the player's paddle as the argument to check collision
function Ball:collidesPaddle(paddle)
    if self.x > paddle.x + paddle.width or paddle.x > self.x + self.width then
        return false
    end

    if self.y > paddle.y + paddle.height or paddle.y > self.y + self.height then
        return false
    end

    return true
end

-- returns the relative ball position in the x and y directions
-- in a way, this returns the coordinates for the ball relative to each brick
function Ball:position()
    temp_x = math.floor(play_ball.x / 64)
    temp_y = math.floor(play_ball.y / 32)

    found_x = -1
    found_y = -1

    for i = 1, 20, 1 do
        if self.y <= 320 then
            for j = 1, 10, 1 do
                if relative_ball_location_y[j] == temp_y then
                    found_y = relative_ball_location_y[j]
                end
            end
        end
        if relative_ball_location_x[i] == temp_x then
            found_x = relative_ball_location_x
        end
    end

    -- return both coordinates if the ball has gone beyond the first layer of bricks from the bottom
    if found_y ~= 0 then
        return {found_x, found_y}
    else
        return {found_x, -1}
    end
end


-- checks if the ball has hit a brick; takes its relative x position as a parameter
function Ball:hit(location_x, location_y)
    if location_y <= 9 then
        return {coordinates[location_y][location_x].x1, ' ', coordinates[location_y][location_x].y1}
    else
        return {9876, ' ', 9876}
    end
end 

-- CHECK THIS
-- checks if the ball has hit a non-blank brick
function Ball:brickHit(location_x, location_y)
    if self.map:tileAt(location_x, location_y).id ~= BLANK_TILE or self.map:tileAt(location_x, location_y).id ~= EMPTY_TILE or
       self.map:tileAt(location_x + 12, location_y + 12).id ~= BLANK_TILE or self.map:tileAt(location_x + 12, location_y + 12).id ~= EMPTY_TILE then
        return true
    else
        return false
    end
end

-- moving the ball
function Ball:update(dt)
    self.x = self.x + self.dx * dt
    self.y = self.y + self.dy * dt
end

function Ball:reset()
    self.x = VIRTUAL_WIDTH / 2
    self.y = VIRTUAL_HEIGHT / 2 + 10 
    self.dx = math.random(2) == 1 and math.random(-80, -100) or math.random(80, 100)
    self.dy = BALL_SPEED_DOWN
    gameState = 'reset'
end

function Ball:render()
    love.graphics.draw(self.texture, self.x, self.y)
end
