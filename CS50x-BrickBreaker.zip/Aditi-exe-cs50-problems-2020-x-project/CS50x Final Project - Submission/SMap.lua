--[[
    Space map class; tiles and environments are different.
    Point system is different.
]]

require 'Util'

SMap = Class{}

BLANK_TILE = -1

-- in pixels
TILE_WIDTH = 64
TILE_HEIGHT = 32

-- first generation of map; no collisions
RED = 1
BLUE = 5
GREY = 25
PURPLE = 24
GOLDEN = 22

RED_2 = 18
BLUE_2 = 11
GREY_2 = 13
PURPLE_2 = 12
GOLDEN_2 = 23

PURPLE_3 = 19
GOLDEN_3 = 20

--[[
-- after one collision
RED_BROKEN = 1
BLUE_BROKEN = 5
GREY_BROKEN = 13
PURPLE_BROKEN = 24
GOLDEN_BROKEN = 22

-- after two collisions
GREY_SMASHED = 13
PURPLE_SMASHED = 24
GOLDEN_SMASHED = 24

-- after three collisions
GOLDEN_PRE_END = 23

-- after four collisions
GOLDEN_END = 23
]]

blankTileCount = 0

function SMap:init()

    self.spritesheet = love.graphics.newImage('graphics/Upscaled_Bricks/012-C.png')
    self.sprites = generateQuads(self.spritesheet, 64, 32)

    -- in pixels
    self.tileWidth = 64
    self.tileHeight = 32

    -- arbitrary numbers to fix a map width and height (in number of tiles)
    self.mapWidth = 20
    self.mapHeight = 10

    -- store width and height of map in pixels
    self.mapWidthPixels = self.mapWidth * self.tileWidth
    self.mapHeightPixels = self.mapHeight * self.tileHeight

    self.tiles = {}

    -- associate player paddle with map
    self.player = Paddle(self)

    -- associate ball with map
    self.ball1 = Ball(self)

    -- filling map with empty tiles
    for y = 1, VIRTUAL_HEIGHT do
        for x = 1, VIRTUAL_WIDTH do
            self:setTile(x, y, BLANK_TILE)
        end
    end

    -- generate bricks till the middle of the screen in random patterns
    local x = 0
    local y = 0
    local y_limit = VIRTUAL_HEIGHT / 2

    for y = 1, self.mapHeight do
        for x = 1, self.mapWidth do
            -- generating bricks
            if math.random(4) == 1 then
                -- 25% chance of generating a red brick
                self:setTile(x, y, RED)
            elseif math.random(2) == 2 then
                -- 25% chance of generating a blue brick
                self:setTile(x, y, BLUE)
            elseif math.random(4) == 3 then
                -- 25% chance of generating a grey brick
                self:setTile(x, y, GREY)
            else
                -- 25% chance of generating a purple brick
                self:setTile(x, y, PURPLE)
            end

            -- 4% chance of generating a special high-valued brick
            if math.random(25) == 1 then
                self:setTile(x, y, GOLDEN)
            end

        end
    end
end

function SMap:update(dt)
    self.player:update(dt)
end

-- returns the integer value for the tile at a given x-y coordinate
function SMap:getTile(x, y)
    return self.tiles[(y - 1) * self.mapWidth + x]
end

-- sets a tile at a given x-y coordinate to an integer value (here, id)
function SMap:setTile(x, y, id)
    self.tiles[(y - 1) * self.mapWidth + x] = id
end

function SMap:getTileId(x, y)
    return self:getTile(math.floor(x / self.tileWidth) + 1, math.floor(y / self.tileHeight) + 1)
end

function SMap:tileAt(x, y)
    return {
        x = math.floor(x / self.tileWidth) + 1,
        y = math.floor(y / self.tileHeight) + 1,
        id = self:getTile(math.floor(x / self.tileWidth) + 1, math.floor(y / self.tileHeight) + 1)
    }
end

-- checks if the map has been cleared entirely
function SMap:mapClear()
    for j = 1, self.mapHeight do
        for i = 1, self.mapWidth do
            if self:tileAt(i, j).id == BLANK_TILE then
                blankTileCount = blankTileCount + 1
            end
        end
    end

    if blankTileCount == 200 then
        return true
    else
        return false
    end
end

function SMap:render()
    for y = 1, self.mapHeight do
        for x = 1, self.mapWidth do

            local tile = self:getTile(x, y)

            if tile ~= BLANK_TILE then
                love.graphics.draw(self.spritesheet, self.sprites[tile],
                    (x - 1) * self.tileWidth, (y - 1) * self.tileHeight)
            end
        end
    end
end