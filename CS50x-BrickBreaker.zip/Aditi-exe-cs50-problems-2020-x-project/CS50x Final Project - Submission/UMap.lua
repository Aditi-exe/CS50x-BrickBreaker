require 'Util'

UMap = Class{}

EMPTY_TILE = -1
BLANK_TILE = -1
NO_TILE = -1

-- in pixels
TILE_WIDTH = 64
TILE_HEIGHT = 32

DARK_BLUE = 5
LIGHT_BLUE = 11
SKY_BLUE = 9
AQUAMARINE = 15
PINK_GOLD = 23
DARK_GREEN = 16

DARK_BLUE_2 = 8
AQUAMARINE_2 = 14
PINK_GOLD_2 = 2
DARK_GREEN_2 = 17

DARK_GREEN_3 = 4

emptyTileCount = 0
tileCount = 0

umap_background = love.graphics.newImage('graphics/backgrounds/umap_background.png')

function UMap:init()

    self.spritesheet = love.graphics.newImage('graphics/Upscaled_Bricks/005-C.png')
    --self.spritesheet = love.graphics.newImage('graphics/brick_styles/Bricks_2.png')
    self.sprites = generateQuads(self.spritesheet, 64, 32)

    -- in pixels
    self.tileWidth = 64
    self.tileHeight = 32

    -- arbitrary numbers to fix a map width and height (in number of tiles)
    self.mapWidth = 20
    self.mapHeight = 10

    -- store width and height of map in pixels
    self.mapWidthPixels = self.mapWidth * self.tileWidth
    self.mapHeightPixels = self.mapHeight * self.tileHeight

    self.tiles = {}

    -- associate player paddle with map
    self.player = Paddle(self)

    -- associate ball with map
    self.ball1 = Ball(self)


    -- filling map with empty tiles
    for y = 1, VIRTUAL_HEIGHT do
        for x = 1, VIRTUAL_WIDTH do
            self:setTile(x, y, EMPTY_TILE)
        end
    end

    -- generate bricks till the middle of the screen in random patterns
    local x = 0
    local y = 0
    local y_limit = VIRTUAL_HEIGHT / 2

    --[[
    for y = 1, self.mapHeight do
        for x = 1, self.mapWidth do
            -- generating bricks
            if math.random(4) == 1 then
                -- 20% chance of generating a red brick
                self:setTile(x, y, DARK_BLUE)
            elseif math.random(4) == 2 then
                -- 20% chance of generating a blue brick
                self:setTile(x, y, LIGHT_BLUE)
            elseif math.random(4) == 3 then
                -- 20% chance of generating a grey brick
                self:setTile(x, y, SKY_BLUE)
            else 
                -- 20% chance of generating an aquamarine brick
                self:setTile(x, y, AQUAMARINE)
            end

            -- 4% chance of generating a special high-valued brick
            if math.random(25) == 1 then
                self:setTile(x, y, PINK_GOLD)
            end

            if math.random(25) == 1 then
                self:setTile(x, y, DARK_GREEN)
            end

        end
    end
    ]]


    for x = 1, self.mapWidth do
        for y = 1, math.random(8, self.mapHeight) do
            -- generating bricks
            if math.random(4) == 1 then
                -- 20% chance of generating a red brick
                self:setTile(x, y, DARK_BLUE)
            elseif math.random(4) == 2 then
                -- 20% chance of generating a blue brick
                self:setTile(x, y, LIGHT_BLUE)
            elseif math.random(4) == 3 then
                -- 20% chance of generating a grey brick
                self:setTile(x, y, SKY_BLUE)
            else 
                -- 20% chance of generating an aquamarine brick
                self:setTile(x, y, AQUAMARINE)
            end
            --tileCount = tileCount + 1

            -- 4% chance of generating a special high-valued brick
            if math.random(25) == 1 then
                self:setTile(x, y, PINK_GOLD)
            end

            if math.random(25) == 1 then
                self:setTile(x, y, DARK_GREEN)
            end
            tileCount = tileCount + 1
        end
    end

end

function UMap:update(dt)
    self.player:update(dt)
end

-- returns the integer value for the tile at a given x-y coordinate
function UMap:getTile(x, y)
    return self.tiles[(y - 1) * self.mapWidth + x]
end

-- sets a tile at a given x-y coordinate to an integer value (here, id)
function UMap:setTile(x, y, id)
    self.tiles[(y - 1) * self.mapWidth + x] = id
end

function UMap:getTileId(x, y)
    return self:getTile(math.floor(x / self.tileWidth) + 1, math.floor(y / self.tileHeight) + 1)
end

function UMap:tileAt(x, y)
    return {
        x = math.floor(x / self.tileWidth) + 1,
        y = math.floor(y / self.tileHeight) + 1,
        id = self:getTile(math.floor(x / self.tileWidth) + 1, math.floor(y / self.tileHeight) + 1)
    }
end

-- checks if the map has been cleared entirely
function UMap:mapClear2()
    for j = 1, self.mapHeight do
        for i = 1, self.mapWidth do
            if self:tileAt(i, j).id == EMPTY_TILE then
                emptyTileCount = emptyTileCount + 1
            end
        end
    end

    if emptyTileCount == tileCount then
        return true
    else
        return false
    end
end

function UMap:render()
    for y = 1, self.mapHeight do
        for x = 1, self.mapWidth do

            local tile = self:getTile(x, y)

            if tile ~= EMPTY_TILE then
                love.graphics.draw(self.spritesheet, self.sprites[tile],
                    (x - 1) * self.tileWidth, (y - 1) * self.tileHeight)
            end

        end
    end

end